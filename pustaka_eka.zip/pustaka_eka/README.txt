- Memanggil : http://localhost/pustaka_booking/index.php/Latihan1

- Penjumlahan : http://localhost/pustaka_booking/index.php/Latihan1/penjumlahan/5/10 (Latihan1)

- Penjumlahan : http://localhost/pustaka_booking/index.php/Latihan2/penjumlahan/5/10 (Latihan2)