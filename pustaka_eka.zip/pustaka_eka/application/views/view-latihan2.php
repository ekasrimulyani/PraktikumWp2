<html>

	<head>
		<title> Latihan 2 </title>
	</head>
	
	<body>

		Hello friends. Let's learn Web Programming II EKA SRI MULYANI..<br>
		Nilai 1 = <?= $nilai1; ?>
		Nilai 2 = <?= $nilai2; ?>
		ini hasil dari pemodelan dengan metode penjumlahan
		<?= $nilai1." + ".$nilai2." = ".$hasil; ?>

	</body>

	

</html>