<section> 
<h1><?php echo $judul ?></h1> 
<h4>Nama</h4> 
<ul type="disc"> 
    <li>Nama Depan : eka</li> 
    <li>Nama Belakang : eka sri mulyani</li> 
</ul> 
<h4>Alamat</h4> 
<ul type="disc"> 
    <li> Jalan Rambutan Tegal</li> </ul> 
    <h4>Tempat Lahir</h4> 
<ul type="disc"> 
    <li>Tegal</li> 
</ul> 
<h4>Olah Raga Favorit</h4> 
<ul type="square"> 
    <li>Bulutangkis</li> 
    <li>basket</li> 
</ul> 
</section> 