<footer>
	<a href='http://www.detik.com'>RentalBuku</a> </footer>
</div>
</body>
</html>
