<!DOCTYPE html>
<html>
<head>
 <!-- Load file CSS Bootstrap offline -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
  <script src="<?php echo base_url()?>/assets/bootstrap/js/jquery-3.3.1.min.js"></script>
</head>
<body>
<div class="jumbotron text-center">
  <h1>Eka Sri Mulyani</h1>
  <p>Mahasiswi Politeknik Harapan Bersama Tegal</p> 
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>Eka Sri Mulyani</h3>
      <p>NIM    : 18090018</p>
      <p>Kelas  : 5D</p>
    </div>
    <div class="col-sm-4">
      <h3>Eka Sri Mulyani</h3>
      <p>NIM    : 18090018</p>
      <p>Kelas  : 5D</p>
    </div>
    <div class="col-sm-4">
      <h3>Eka Sri Mulyani</h3>
      <p>NIM    : 18090018</p>
      <p>Kelas  : 5D</p>
    </div>
  </div>
</div>

</body>
</html>
